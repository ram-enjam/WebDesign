Mega Dropdown
=========

A responsive and easy to customise mega-dropdown component.

[Article on CodyHouse](http://codyhouse.co/gem/mega-dropdown/)

[Demo](http://codyhouse.co/demo/mega-dropdown/index.html)
 
[Terms](http://codyhouse.co/terms/)

Icons: [Nucleo Library](https://nucleoapp.com/)

Diagonal movement plugin: [jQuery-menu-aim](https://github.com/kamens/jQuery-menu-aim)
